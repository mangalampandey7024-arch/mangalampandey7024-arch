/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart3, 
  ClipboardCheck, 
  Combine, 
  Download, 
  LayoutDashboard, 
  Settings, 
  ShieldAlert,
  ArrowRight,
  Loader2,
  FolderOpen,
  Plus,
  Search as SearchIcon
} from 'lucide-react';
import { SoilData, AnalysisResult, Project, analyzeSoil } from './services/geminiService';

// Component Imports
import SoilInputForm from './components/SoilInputForm';
import AnalysisDashboard from './components/AnalysisDashboard';
import ProjectRegistry from './components/ProjectRegistry';

export default function App() {
  const [activeTab, setActiveTab] = useState<'registry' | 'input' | 'dashboard' | 'report'>('registry');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [globalSearch, setGlobalSearch] = useState('');

  // Load projects from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('geotech_projects');
    if (saved) {
      try {
        setProjects(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load projects", e);
      }
    }
  }, []);

  // Save projects to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('geotech_projects', JSON.stringify(projects));
  }, [projects]);

  const selectedProject = projects.find(p => p.id === selectedProjectId);

  const handleAnalyze = async (data: SoilData) => {
    setIsAnalyzing(true);
    try {
      const result = await analyzeSoil(data);
      const newProject: Project = {
        id: Math.random().toString(36).substr(2, 9),
        name: data.location || "Untitled Site",
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        data,
        result
      };
      setProjects([newProject, ...projects]);
      setSelectedProjectId(newProject.id);
      setActiveTab('dashboard');
    } catch (error) {
      console.error("Analysis failed:", error);
      alert("Analysis failed. Please check your inputs or try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const deleteProject = (id: string) => {
    setProjects(projects.filter(p => p.id !== id));
    if (selectedProjectId === id) setSelectedProjectId(null);
  };

  const selectProject = (id: string) => {
    setSelectedProjectId(id);
    setActiveTab('dashboard');
  };

  // Filter projects for global search in header (dropdown or just navigation)
  const searchResults = projects.filter(p => 
    p.name.toLowerCase().includes(globalSearch.toLowerCase())
  );

  return (
    <div className="flex h-screen bg-[#F8F9FA] text-[#1A1A1A] font-sans selection:bg-orange-100">
      {/* Sidebar */}
      <aside className="w-64 bg-[#141414] text-[#E4E3E0] flex flex-col border-r border-[#141414]">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-orange-600 flex items-center justify-center rounded-sm">
            <Combine className="text-[#E4E3E0]" size={24} />
          </div>
          <div>
            <h1 className="font-bold text-lg tracking-tight">TerraMind</h1>
            <p className="text-[10px] uppercase tracking-widest opacity-60">Geotech AI v1.0</p>
          </div>
        </div>

        <nav className="flex-1 mt-6 px-4 space-y-2">
          <NavItem 
            icon={<FolderOpen size={20} />} 
            label="Active Projects" 
            active={activeTab === 'registry'} 
            onClick={() => setActiveTab('registry')} 
          />
          <NavItem 
            icon={<Plus size={20} />} 
            label="New Analysis" 
            active={activeTab === 'input'} 
            onClick={() => {
              setSelectedProjectId(null);
              setActiveTab('input');
            }} 
          />
          
          <div className="pt-4 pb-2 px-4">
            <div className="h-px bg-zinc-800 w-full mb-4"></div>
            <p className="text-[10px] uppercase font-black tracking-widest text-zinc-500 mb-4">Current Project</p>
          </div>

          <NavItem 
            icon={<BarChart3 size={20} />} 
            label="Visualizations" 
            active={activeTab === 'dashboard'} 
            disabled={!selectedProject}
            onClick={() => setActiveTab('dashboard')} 
          />
          <NavItem 
            icon={<ClipboardCheck size={20} />} 
            label="Formal Report" 
            active={activeTab === 'report'} 
            disabled={!selectedProject}
            onClick={() => setActiveTab('report')} 
          />
        </nav>

        <div className="p-4 bg-zinc-900 mx-4 mb-8 rounded-lg border border-zinc-800">
          <div className="flex items-center gap-2 mb-2">
            <ShieldAlert size={16} className="text-orange-500" />
            <span className="text-xs font-semibold uppercase tracking-wider">Legal Notice</span>
          </div>
          <p className="text-[10px] leading-relaxed opacity-50 italic">
            Output is for preliminary estimation and feasibility studies only. Must be verified by a licensed PE.
          </p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 border-b border-zinc-200 bg-white flex items-center justify-between px-8">
          <div className="flex items-center gap-8 flex-1">
            <div className="flex items-center gap-4">
              <h2 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 shrink-0">
                Site: <span className="text-[#141414]">{selectedProject?.name || (activeTab === 'input' ? "New Project" : "Not Selected")}</span>
              </h2>
              {selectedProject && (
                <span className="px-2 py-0.5 bg-zinc-100 rounded text-[10px] font-bold text-zinc-600 uppercase shrink-0">
                  ID: {selectedProject.id}
                </span>
              )}
            </div>

            {/* Global Search Bar in Header */}
            <div className="max-w-md w-full relative group">
              <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 group-focus-within:text-orange-600 transition-colors" size={16} />
              <input 
                type="text" 
                placeholder="Find project..." 
                value={globalSearch}
                onChange={(e) => setGlobalSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-1.5 bg-zinc-50 border border-zinc-100 rounded-sm text-xs outline-none focus:border-orange-500 focus:bg-white transition-all"
              />
              {globalSearch && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-zinc-200 shadow-xl rounded-sm z-50 overflow-hidden max-h-60 overflow-y-auto">
                  {searchResults.map(p => (
                    <button 
                      key={p.id}
                      onClick={() => {
                        selectProject(p.id);
                        setGlobalSearch('');
                      }}
                      className="w-full text-left px-4 py-2 text-xs hover:bg-zinc-50 flex flex-col gap-0.5"
                    >
                      <span className="font-bold">{p.name}</span>
                      <span className="text-[10px] opacity-50">{p.data.soilType} • {p.date}</span>
                    </button>
                  ))}
                  {searchResults.length === 0 && (
                    <div className="px-4 py-3 text-[10px] text-zinc-400 uppercase font-bold text-center">No results</div>
                  )}
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="text-zinc-400 hover:text-zinc-600 transition-colors">
              <Settings size={18} />
            </button>
            <div className="w-8 h-8 rounded-full bg-zinc-200 border border-zinc-300 overflow-hidden">
              <img 
                src="https://picsum.photos/seed/engineer/100/100" 
                alt="Profile" 
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </header>

        <section className="flex-1 overflow-y-auto p-8 relative no-scrollbar">
          <AnimatePresence mode="wait">
            {activeTab === 'registry' && (
              <motion.div
                key="registry"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="max-w-4xl mx-auto"
              >
                <div className="mb-8 flex justify-between items-end">
                  <div>
                    <h3 className="text-3xl font-serif italic mb-2">Projects Registry</h3>
                    <p className="text-zinc-500 text-sm">Overview of all active geotechnical investigations.</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] font-black uppercase tracking-widest text-zinc-300 block mb-1">Total Active</span>
                    <span className="text-2xl font-serif italic text-orange-600">{projects.length}</span>
                  </div>
                </div>
                <ProjectRegistry 
                  projects={projects} 
                  onSelectProject={selectProject} 
                  onDeleteProject={deleteProject} 
                />
              </motion.div>
            )}

            {activeTab === 'input' && (
              <motion.div
                key="input"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="max-w-4xl mx-auto"
              >
                <div className="mb-8">
                  <h3 className="text-3xl font-serif italic mb-2">Technical Specification</h3>
                  <p className="text-zinc-500">Provide the geotechnical and structural data for site evaluation.</p>
                </div>
                <SoilInputForm onAnalyze={handleAnalyze} isAnalyzing={isAnalyzing} />
              </motion.div>
            )}

            {activeTab === 'dashboard' && selectedProject && (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <AnalysisDashboard result={selectedProject.result} data={selectedProject.data} />
              </motion.div>
            )}

            {activeTab === 'report' && selectedProject && (
              <motion.div
                key="report"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="max-w-4xl mx-auto pb-12"
              >
                <ReportView result={selectedProject.result} data={selectedProject.data} />
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      </main>

      {/* Loading Overlay */}
      {isAnalyzing && (
        <div className="fixed inset-0 bg-[#E4E3E0]/60 backdrop-blur-sm z-50 flex flex-col items-center justify-center">
          <div className="bg-[#141414] text-[#E4E3E0] p-12 rounded-sm shadow-2xl flex flex-col items-center gap-6 max-w-sm text-center">
            <Loader2 className="animate-spin text-orange-500" size={48} />
            <div>
              <h4 className="text-xl font-serif italic mb-2">Simulating Soil Mechanics</h4>
              <p className="text-xs opacity-60 uppercase tracking-widest leading-relaxed">
                Interpolating SPT N-values and calculating allowable bearing capacity...
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function NavItem({ icon, label, active, disabled, onClick }: { 
  icon: React.ReactNode; 
  label: string; 
  active?: boolean; 
  disabled?: boolean;
  onClick: () => void;
}) {
  return (
    <button 
      onClick={onClick}
      disabled={disabled}
      className={`
        w-full flex items-center gap-3 px-4 py-3 rounded-md transition-all duration-200
        ${active ? 'bg-orange-600 text-white shadow-lg' : 'text-zinc-400 hover:text-white hover:bg-zinc-800'}
        ${disabled ? 'opacity-30 cursor-not-allowed pointer-events-none' : 'cursor-pointer'}
      `}
    >
      {icon}
      <span className="text-sm font-medium">{label}</span>
      {active && <ArrowRight size={14} className="ml-auto" />}
    </button>
  );
}

function ReportView({ result, data }: { result: AnalysisResult; data: SoilData }) {
  return (
    <div className="bg-white border border-zinc-200 shadow-xl p-12 font-serif text-[#141414] max-w-4xl mx-auto rounded-sm print:shadow-none print:border-none">
      <div className="flex justify-between items-start border-b-2 border-zinc-900 pb-12 mb-12">
        <div>
          <h1 className="text-4xl font-black uppercase tracking-tighter mb-2">Geotechnical Report</h1>
          <div className="text-xs uppercase tracking-widest font-sans font-bold flex flex-col gap-1">
            <span className="text-zinc-500">Document No: <span className="text-zinc-900">REP-2026-0042</span></span>
            <span className="text-zinc-500">Date: <span className="text-zinc-900">April 17, 2026</span></span>
            <span className="text-zinc-500">Location: <span className="text-zinc-900">{data.location || "Confidential Site"}</span></span>
          </div>
        </div>
        <div className="text-right">
          <Combine size={48} className="ml-auto mb-4 text-orange-600" />
          <div className="text-[10px] uppercase font-sans font-black tracking-widest">
            TerraMind Analytics System
          </div>
        </div>
      </div>

      <div className="space-y-12">
        <section>
          <h2 className="text-sm font-sans font-black uppercase tracking-[0.2em] border-b border-zinc-200 pb-2 mb-6">01. Executive Summary</h2>
          <p className="leading-relaxed text-lg italic opacity-80">{result.summary}</p>
        </section>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <section>
            <h2 className="text-sm font-sans font-black uppercase tracking-[0.2em] border-b border-zinc-200 pb-2 mb-4">02. Soil Properties</h2>
            <div className="space-y-4">
              <DataRow label="Classification" value={result.soilClassification} />
              <DataRow label="Base Soil Type" value={data.soilType} />
              <DataRow label="Avg SPT N-value" value={(data.sptNValues.reduce((a, b) => a + b, 0) / data.sptNValues.length).toFixed(1)} />
              <DataRow label="Water Table" value={data.groundWaterDepth ? `${data.groundWaterDepth}m` : 'Not recorded'} />
            </div>
          </section>

          <section>
            <h2 className="text-sm font-sans font-black uppercase tracking-[0.2em] border-b border-zinc-200 pb-2 mb-4">03. Engineering Design</h2>
            <div className="space-y-4">
              <DataRow label="Bearing Capacity" value={`${result.bearingCapacity} kN/m²`} highlight />
              <DataRow label="Foundation Type" value={result.recommendedFoundation} highlight />
              <DataRow label="Recommended Depth" value={`${result.foundationDepth}m`} />
              <DataRow label="Structural Load" value={`${data.estimatedLoad} kN`} />
            </div>
          </section>
        </div>

        <section>
          <h2 className="text-sm font-sans font-black uppercase tracking-[0.2em] border-b border-zinc-200 pb-2 mb-4">04. Risk & Mitigations</h2>
          <div className="bg-orange-50 border border-orange-100 p-6 italic leading-relaxed text-orange-900">
            {result.riskAssessment}
          </div>
        </section>

        <section>
          <h2 className="text-sm font-sans font-black uppercase tracking-[0.2em] border-b border-zinc-200 pb-2 mb-4">05. Alternative Designs</h2>
          <ul className="list-disc pl-5 space-y-2 opacity-70">
            {result.alternatives.map((alt, i) => (
              <li key={i}>{alt}</li>
            ))}
          </ul>
        </section>

        <div className="pt-24 flex justify-between items-end border-t border-zinc-200 mt-24">
          <div className="space-y-4">
            <div className="h-0.5 w-48 bg-zinc-300"></div>
            <p className="text-[10px] uppercase font-sans font-bold text-zinc-400">Software Certification</p>
          </div>
          <button 
            onClick={() => window.print()}
            className="flex items-center gap-2 px-6 py-3 bg-zinc-900 text-white font-sans text-xs uppercase tracking-widest font-black hover:bg-orange-600 transition-colors rounded-sm shadow-lg no-print"
          >
            <Download size={14} /> Download PDF
          </button>
        </div>
      </div>
    </div>
  );
}

function DataRow({ label, value, highlight }: { label: string; value: string | number; highlight?: boolean }) {
  return (
    <div className={`flex justify-between items-center py-2 border-b border-zinc-50 ${highlight ? 'text-orange-600' : ''}`}>
      <span className="text-xs font-sans font-bold uppercase tracking-wider opacity-50">{label}</span>
      <span className={`font-sans font-black ${highlight ? 'text-sm' : 'text-xs'}`}>{value}</span>
    </div>
  );
}
