import React, { useState } from 'react';
import { 
  Search, 
  MapPin, 
  Calendar, 
  ArrowRight, 
  Trash2, 
  Building2, 
  MoreVertical,
  Filter
} from 'lucide-react';
import { Project } from '../services/geminiService';
import { motion } from 'motion/react';

interface Props {
  projects: Project[];
  onSelectProject: (id: string) => void;
  onDeleteProject: (id: string) => void;
}

export default function ProjectRegistry({ projects, onSelectProject, onDeleteProject }: Props) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProjects = projects.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.data.buildingType.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 bg-white p-4 border border-zinc-200 rounded-sm shadow-sm">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
          <input 
            type="text" 
            placeholder="Search active projects by location or building type..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-sm border-b border-zinc-100 focus:border-orange-500 outline-none transition-all placeholder:text-zinc-400 placeholder:italic"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 text-xs font-bold uppercase tracking-widest text-zinc-500 hover:text-zinc-900 border-l border-zinc-100 pl-6">
          <Filter size={14} />
          Filter
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredProjects.length > 0 ? (
          filteredProjects.map((project, index) => (
            <motion.div 
              key={project.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="group bg-white border border-zinc-200 rounded-sm hover:border-orange-500 hover:shadow-md transition-all cursor-pointer flex items-center p-4 gap-6"
              onClick={() => onSelectProject(project.id)}
            >
              <div className="w-12 h-12 bg-zinc-50 flex items-center justify-center border border-zinc-100 rounded-sm text-zinc-400 group-hover:bg-orange-50 group-hover:text-orange-600 transition-colors">
                <Building2 size={24} />
              </div>

              <div className="flex-1 grid grid-cols-4 gap-4 items-center">
                <div className="col-span-2">
                  <h4 className="font-serif italic text-lg leading-tight group-hover:text-orange-600 transition-colors">
                    {project.name}
                  </h4>
                  <div className="flex items-center gap-3 mt-1">
                    <div className="flex items-center gap-1 text-[10px] uppercase font-bold text-zinc-400">
                      <MapPin size={10} />
                      {project.data.soilType}
                    </div>
                    <div className="flex items-center gap-1 text-[10px] uppercase font-bold text-zinc-400">
                      <Calendar size={10} />
                      {project.date}
                    </div>
                  </div>
                </div>

                <div>
                  <div className="text-[10px] uppercase font-black tracking-widest text-zinc-300 mb-1">Recommended</div>
                  <div className="text-xs font-bold text-zinc-600">{project.result.recommendedFoundation}</div>
                </div>

                <div className="text-right">
                  <div className="text-[10px] uppercase font-black tracking-widest text-zinc-300 mb-1">Capacity</div>
                  <div className="text-xs font-bold text-zinc-900">{project.result.bearingCapacity} kN/m²</div>
                </div>
              </div>

              <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity pl-4 border-l border-zinc-50">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteProject(project.id);
                  }}
                  className="p-2 text-zinc-300 hover:text-red-500 transition-colors"
                >
                  <Trash2 size={16} />
                </button>
                <div className="p-2 text-zinc-300">
                  <ArrowRight size={16} />
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="py-20 text-center bg-zinc-50 border border-dashed border-zinc-200 rounded-sm">
            <div className="text-zinc-400 mb-2">No projects found matching your search.</div>
            <p className="text-[10px] uppercase font-bold tracking-widest text-zinc-300 italic">Try a different site location or soil type.</p>
          </div>
        )}
      </div>
    </div>
  );
}
