import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  AreaChart, 
  Area 
} from 'recharts';
import { 
  Compass, 
  ShieldCheck, 
  ArrowUpRight, 
  Layers, 
  Activity, 
  Info,
  Construction
} from 'lucide-react';
import { AnalysisResult, SoilData } from '../services/geminiService';

interface Props {
  result: AnalysisResult;
  data: SoilData;
}

export default function AnalysisDashboard({ result, data }: Props) {
  // Prepare data for Recharts: depth vs SPT, filtering out any NaN values
  const chartData = data.depths
    .map((d, i) => ({
      depth: d,
      nValue: data.sptNValues[i]
    }))
    .filter(point => !Number.isNaN(point.depth) && !Number.isNaN(point.nValue));

  return (
    <div className="space-y-8 pb-12">
      {/* Hero Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard 
          icon={<Compass className="text-orange-500" />} 
          label="Bearing Capacity" 
          value={`${result.bearingCapacity}`} 
          unit="kN/m²" 
        />
        <StatCard 
          icon={<Construction className="text-blue-500" />} 
          label="Rec. Foundation" 
          value={result.recommendedFoundation} 
          unit="Type" 
        />
        <StatCard 
          icon={<ArrowUpRight className="text-green-500" />} 
          label="Target Depth" 
          value={`${result.foundationDepth}`} 
          unit="Meters" 
        />
        <StatCard 
          icon={<ShieldCheck className="text-zinc-400" />} 
          label="Classification" 
          value={result.soilClassification} 
          unit="USCS" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* SPT N-Value Profile Chart */}
        <div className="lg:col-span-2 bg-white p-6 border border-zinc-200 rounded-sm shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Layers size={20} className="text-zinc-600" />
              <h4 className="text-xs font-black uppercase tracking-widest">SPT N-Value Profile</h4>
            </div>
            <div className="text-[10px] uppercase font-bold text-zinc-400 flex gap-4">
              <span>Borehole: BH-1</span>
              <span>Method: Donut Hammer</span>
            </div>
          </div>
          
          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                layout="vertical"
                data={chartData}
                margin={{ top: 10, right: 30, left: 20, bottom: 10 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={true} stroke="#f0f0f0" />
                <XAxis type="number" hide />
                <YAxis 
                  dataKey="depth" 
                  type="number" 
                  reversed 
                  label={{ value: 'Depth (m)', angle: -90, position: 'insideLeft', style: { fontSize: '10px', textTransform: 'uppercase', fontWeight: 600 } }}
                  tick={{ fontSize: 10, fontWeight: 600 }}
                  domain={[0, 'auto']}
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '0', border: '1px solid #141414', fontFamily: 'monospace', fontSize: '12px' }}
                  itemStyle={{ fontSize: '10px', textTransform: 'uppercase', fontWeight: 800 }}
                  labelStyle={{ display: 'none' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="nValue" 
                  stroke="#EA580C" 
                  fill="#FFF7ED" 
                  strokeWidth={2}
                  dot={{ r: 4, fill: '#EA580C', strokeWidth: 2, stroke: '#fff' }}
                  activeDot={{ r: 6, stroke: '#EA580C', strokeWidth: 0, fill: '#EA580C' }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 pt-4 border-t border-zinc-100 flex justify-center gap-8">
            <LegendItem color="bg-orange-600" label="Resistance (N)" />
            <LegendItem color="bg-zinc-100" label="Soil Profile" />
          </div>
        </div>

        {/* AI Recommendations & Logic */}
        <div className="space-y-6">
          <div className="bg-[#141414] text-[#E4E3E0] p-6 rounded-sm shadow-xl">
            <div className="flex items-center gap-3 mb-6">
              <Activity size={20} className="text-orange-500" />
              <h4 className="text-xs font-black uppercase tracking-widest">Analysis Engine Commentary</h4>
            </div>
            <p className="font-serif italic text-lg leading-relaxed opacity-90 mb-6">
              "{result.summary}"
            </p>
            <div className="space-y-4">
              <h5 className="text-[10px] font-black uppercase tracking-widest text-zinc-500 border-b border-zinc-800 pb-2">Proposed Actions</h5>
              {result.alternatives.map((alt, i) => (
                <div key={i} className="flex gap-3 text-xs leading-relaxed opacity-80">
                  <div className="w-5 h-5 bg-zinc-800 flex items-center justify-center shrink-0 text-[10px] font-bold">{i + 1}</div>
                  <p>{alt}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-orange-50 border border-orange-100 p-6 rounded-sm">
            <div className="flex items-center gap-3 mb-4">
              <ShieldCheck size={20} className="text-orange-600" />
              <h4 className="text-xs font-black uppercase tracking-widest text-orange-900">Safety Verification</h4>
            </div>
            <p className="text-xs text-orange-800 leading-relaxed italic">
              {result.riskAssessment}
            </p>
          </div>

          <div className="p-4 bg-zinc-100 flex gap-3 rounded-sm">
            <Info size={18} className="text-zinc-400 shrink-0" />
            <p className="text-[10px] text-zinc-500 leading-relaxed uppercase font-bold tracking-tight">
              Calculations assume a factor of safety (FoS) of 3.0. Settlement analysis is based on Terzaghi's consolidation theory.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, unit }: { icon: React.ReactNode; label: string; value: string; unit: string }) {
  return (
    <div className="bg-white p-6 border border-zinc-200 rounded-sm shadow-sm group hover:border-[#141414] transition-all cursor-default">
      <div className="flex items-center gap-3 mb-4 opacity-70 group-hover:opacity-100">
        {icon}
        <span className="text-[10px] font-black uppercase tracking-widest text-zinc-400 group-hover:text-zinc-900">{label}</span>
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-3xl font-serif font-black italic tracking-tighter">{value}</span>
        <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">{unit}</span>
      </div>
    </div>
  );
}

function LegendItem({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className={`w-3 h-3 rounded-full ${color}`}></div>
      <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">{label}</span>
    </div>
  );
}
