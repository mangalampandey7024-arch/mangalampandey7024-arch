import React, { useState } from 'react';
import { Plus, Trash2, ArrowRight, Table as TableIcon, Activity, Info } from 'lucide-react';
import { SoilData } from '../services/geminiService';

interface Props {
  onAnalyze: (data: SoilData) => void;
  isAnalyzing: boolean;
}

const SOIL_TYPES = [
  "Sand", "Clay", "Silt", "Gravel", "Peat", "Loam", "Weathered Rock", "Dense Sand", "Stiff Clay"
];

const BUILDING_TYPES = [
  "Residential (Single Family)", 
  "Commercial (Low-rise)", 
  "Industrial Warehouse", 
  "High-rise Residential", 
  "Bridge Abutment", 
  "Retaining Wall"
];

export default function SoilInputForm({ onAnalyze, isAnalyzing }: Props) {
  const [formData, setFormData] = useState<Partial<SoilData>>({
    location: '',
    soilType: 'Clay',
    buildingType: 'Residential (Single Family)',
    estimatedLoad: 500,
    sptNValues: [12, 18, 22],
    depths: [1.5, 3.0, 4.5],
    groundWaterDepth: 5,
    moistureContent: 15
  });

  const handleAddSpt = () => {
    const lastDepth = formData.depths?.[formData.depths.length - 1] || 0;
    setFormData({
      ...formData,
      sptNValues: [...(formData.sptNValues || []), 10],
      depths: [...(formData.depths || []), lastDepth + 1.5]
    });
  };

  const handleRemoveSpt = (index: number) => {
    const newN = [...(formData.sptNValues || [])];
    const newD = [...(formData.depths || [])];
    newN.splice(index, 1);
    newD.splice(index, 1);
    setFormData({ ...formData, sptNValues: newN, depths: newD });
  };

  const handleSptChange = (index: number, field: 'n' | 'd', value: string) => {
    const num = value === '' ? NaN : parseFloat(value);
    if (field === 'n') {
      const newN = [...(formData.sptNValues || [])];
      newN[index] = num;
      setFormData({ ...formData, sptNValues: newN });
    } else {
      const newD = [...(formData.depths || [])];
      newD[index] = num;
      setFormData({ ...formData, depths: newD });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.soilType && formData.buildingType && formData.sptNValues && formData.depths) {
      onAnalyze(formData as SoilData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left Column: Basic Info */}
        <div className="space-y-6">
          <SectionHeader icon={<Activity size={18} />} title="Project Context" />
          
          <div className="space-y-4">
            <Field label="Project Location / Site Name">
              <input 
                type="text" 
                value={formData.location}
                onChange={e => setFormData({ ...formData, location: e.target.value })}
                placeholder="e.g. Green Valley Plot B-12"
                className="input-field"
              />
            </Field>

            <div className="grid grid-cols-2 gap-4">
              <Field label="Building Category">
                <select 
                  value={formData.buildingType}
                  onChange={e => setFormData({ ...formData, buildingType: e.target.value })}
                  className="input-field"
                >
                  {BUILDING_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </Field>
              <Field label="Estimated Column Load (kN)">
                <input 
                  type="number" 
                  value={Number.isNaN(formData.estimatedLoad) ? '' : (formData.estimatedLoad ?? '')}
                  onChange={e => setFormData({ ...formData, estimatedLoad: e.target.value === '' ? NaN : parseFloat(e.target.value) })}
                  className="input-field"
                />
              </Field>
            </div>
          </div>

          <SectionHeader icon={<TableIcon size={18} />} title="Soil Parameters" />
          
          <div className="space-y-4">
            <Field label="Primary Soil Classification">
              <select 
                value={formData.soilType}
                onChange={e => setFormData({ ...formData, soilType: e.target.value })}
                className="input-field"
              >
                {SOIL_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </Field>

            <div className="grid grid-cols-2 gap-4">
              <Field label="Ground Water Depth (m)">
                <input 
                  type="number" 
                  step="0.1"
                  value={Number.isNaN(formData.groundWaterDepth) ? '' : (formData.groundWaterDepth ?? '')}
                  onChange={e => setFormData({ ...formData, groundWaterDepth: e.target.value === '' ? NaN : parseFloat(e.target.value) })}
                  className="input-field"
                />
              </Field>
              <Field label="Moisture Content (%)">
                <input 
                  type="number" 
                  step="0.1"
                  value={Number.isNaN(formData.moistureContent) ? '' : (formData.moistureContent ?? '')}
                  onChange={e => setFormData({ ...formData, moistureContent: e.target.value === '' ? NaN : parseFloat(e.target.value) })}
                  className="input-field"
                />
              </Field>
            </div>
          </div>
        </div>

        {/* Right Column: SPT Values */}
        <div className="space-y-6">
          <SectionHeader icon={<Plus size={18} />} title="Borehole Log (SPT N-Values)" />
          
          <div className="bg-white border border-zinc-200 rounded-sm overflow-hidden">
            <div className="grid grid-cols-12 gap-2 p-3 bg-zinc-50 border-b border-zinc-200 text-[10px] uppercase font-bold tracking-widest text-zinc-500">
              <div className="col-span-1">#</div>
              <div className="col-span-5">Depth (m)</div>
              <div className="col-span-5">N-Value (Blows)</div>
              <div className="col-span-1"></div>
            </div>
            
            <div className="max-h-[300px] overflow-y-auto">
              {formData.sptNValues?.map((n, i) => (
                <div key={i} className="grid grid-cols-12 gap-2 p-3 items-center border-b border-zinc-100 group">
                  <div className="col-span-1 text-xs font-mono font-bold text-zinc-400">{i + 1}</div>
                  <div className="col-span-5">
                    <input 
                      type="number" 
                      step="0.1"
                      value={Number.isNaN(formData.depths?.[i]) ? '' : (formData.depths?.[i] ?? '')}
                      onChange={e => handleSptChange(i, 'd', e.target.value)}
                      className="w-full bg-transparent text-sm border-b border-transparent focus:border-zinc-300 outline-none p-1 font-mono"
                    />
                  </div>
                  <div className="col-span-5">
                    <input 
                      type="number" 
                      value={Number.isNaN(n) ? '' : (n ?? '')}
                      onChange={e => handleSptChange(i, 'n', e.target.value)}
                      className="w-full bg-transparent text-sm font-bold border-b border-transparent focus:border-zinc-300 outline-none p-1 font-mono"
                    />
                  </div>
                  <div className="col-span-1 flex justify-end">
                    <button 
                      type="button"
                      onClick={() => handleRemoveSpt(i)}
                      className="text-zinc-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <button 
              type="button"
              onClick={handleAddSpt}
              className="w-full py-3 flex items-center justify-center gap-2 text-[10px] uppercase font-bold tracking-widest text-zinc-400 hover:text-orange-600 hover:bg-zinc-50 transition-all border-t border-zinc-100"
            >
              <Plus size={14} /> Add Sampling Point
            </button>
          </div>

          <div className="p-4 bg-blue-50 border border-blue-100 rounded-sm">
            <div className="flex gap-3">
              <Info className="text-blue-500 shrink-0" size={18} />
              <p className="text-[11px] text-blue-800 leading-relaxed italic">
                ASTM D1586: Standard Test Method for Standard Penetration Test (SPT). Ensure N-values are corrected for overburden pressure and hammer efficiency if required.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="pt-8 flex justify-end">
        <button 
          type="submit"
          disabled={isAnalyzing}
          className="group relative overflow-hidden bg-[#141414] text-white px-10 py-5 rounded-sm font-black uppercase text-xs tracking-[0.2em] shadow-2xl hover:bg-orange-600 transition-all flex items-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isAnalyzing ? (
            <>Initializing Engine...</>
          ) : (
            <>
              Run Geotechnical Analysis
              <ArrowRight className="group-hover:translate-x-1 transition-transform" size={18} />
            </>
          )}
        </button>
      </div>

      <style>{`
        .input-field {
          width: 100%;
          background: white;
          border: 1px solid #E5E7EB;
          padding: 10px 14px;
          font-size: 0.875rem;
          border-radius: 2px;
          outline: none;
          transition: all 0.2s;
        }
        .input-field:focus {
          border-color: #141414;
          box-shadow: 0 0 0 1px #141414;
        }
      `}</style>
    </form>
  );
}

function SectionHeader({ icon, title }: { icon: React.ReactNode; title: string }) {
  return (
    <div className="flex items-center gap-3 pb-2 border-b-2 border-zinc-900">
      <div className="text-zinc-900">{icon}</div>
      <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-900">{title}</h4>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400 block">{label}</label>
      {children}
    </div>
  );
}
