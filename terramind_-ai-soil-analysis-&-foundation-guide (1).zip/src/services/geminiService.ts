import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface SoilData {
  location?: string;
  sptNValues: number[];
  depths: number[];
  soilType: string;
  groundWaterDepth?: number;
  moistureContent?: number;
  buildingType: string;
  estimatedLoad: number; // in kN
}

export interface AnalysisResult {
  bearingCapacity: number;
  recommendedFoundation: string;
  foundationDepth: number;
  riskAssessment: string;
  soilClassification: string;
  summary: string;
  alternatives: string[];
}

export interface Project {
  id: string;
  name: string;
  date: string;
  data: SoilData;
  result: AnalysisResult;
}

export async function analyzeSoil(data: SoilData): Promise<AnalysisResult> {
  const prompt = `Analyze the following geotechnical data and provide foundation recommendations:
    - Soil Type: ${data.soilType}
    - SPT N-values: ${data.sptNValues.join(", ")} at depths ${data.depths.join(", ")} meters
    - Ground Water Table: ${data.groundWaterDepth ?? "Unknown"} meters
    - Moisture Content: ${data.moistureContent ?? "Unknown"}%
    - Building Type: ${data.buildingType}
    - Estimated Column Load: ${data.estimatedLoad} kN

    Provide calculations for bearing capacity (kN/m²) based on SPT N-values (using standard geotechnical empirical formulas like Meyerhof or Terzaghi where applicable).
    Recommend the most suitable foundation type (Shallow, Raft, or Deep/Pile).
    Estimate the required foundation depth.
    Assess risks such as settlement or liquefaction.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      systemInstruction: "You are a professional geotechnical engineer. Provide precise, technical analysis and clear recommendations. Ensure your math for bearing capacity is grounded in empirical geotechnical standards.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          bearingCapacity: { type: Type.NUMBER, description: "Allowable bearing capacity in kN/m2" },
          recommendedFoundation: { type: Type.STRING, description: "The primary recommended foundation type" },
          foundationDepth: { type: Type.NUMBER, description: "Recommended depth in meters" },
          riskAssessment: { type: Type.STRING, description: "Summary of risks like settlement, liquefaction, etc." },
          soilClassification: { type: Type.STRING, description: "USCS or AASHTO classification" },
          summary: { type: Type.STRING, description: "Brief engineering summary" },
          alternatives: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "Alternative foundation options"
          }
        },
        required: ["bearingCapacity", "recommendedFoundation", "foundationDepth", "riskAssessment", "soilClassification", "summary", "alternatives"]
      }
    }
  });

  try {
    return JSON.parse(response.text.trim()) as AnalysisResult;
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    throw new Error("Invalid response format from AI");
  }
}
